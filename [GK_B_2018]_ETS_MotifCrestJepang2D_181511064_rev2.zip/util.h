/*
    File: util.h
    Deskripsi:
    Author: Rhio Adjie Fabian / 181511064
*/

#ifndef util_H
#define util_H
#include "stroke.h"

koordinat getFirstRectPoint(hinomaruOogi data);
void generateMenu();

#endif // util_H


